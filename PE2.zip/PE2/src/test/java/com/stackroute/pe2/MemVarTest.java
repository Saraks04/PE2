package com.stackroute.pe2;

import static org.junit.Assert.*;

import org.junit.*;

public class MemVarTest {

	
	//@SuppressWarnings("deprecation")
	@Test
	public void test1()
	{
		MemberVariable m=new MemberVariable("Harris Potter",30,2500.3);
		String s=m.cal();
		assertEquals("Harris Potter 30 2500.3",s);
	}
	@Test
	public void test2()
	{
		MemberVariable m=new MemberVariable("Bob",60,4500.6);
		String s=m.cal();
		//if the members does not belong to the specified type
		assertNotEquals("Error",s);
	}

}
