package com.stackroute.pe2;

public class EvenNum 
{
	boolean req=false;
     public boolean isEven(int x)
    {
    	 if((x%2)==0)
    	 {
    		 req=true;
    	 }
    	 else
    	 {
    		 req=false;}
    	 return req;
    }
}
