package com.stackroute.pe2;

public class Palin {
	
 public int compute(int num)
 {
	 int rev=0,n;
	 while(num>0)
	 {
		 n=num%10;
		 rev=rev*10+n;
		 n=num/10;
	 }
	 return rev;
 }
}
