package com.stackroute.pe2;
class Member
{
	protected String name;
	protected int age;
	protected double salary;
	
}
public class MemberVariable extends Member
{
	MemberVariable(String name,int age,double salary)
	{
		this.name=name;
		this.age=age;
		this.salary=salary;
	}
	public String cal() 
	{
		String res=this.name+" "+this.age+" "+this.salary;
		return res;
	}
}
