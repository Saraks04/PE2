package com.stackroute.pe2;
import java.lang.Math.*;
public class NumPow {

	public boolean checkpow(int n)
	{
		int res;
		if((n%4)==0)
		{
			res=n/4;
			return true;
		}
		else
			return false;
	}
}
