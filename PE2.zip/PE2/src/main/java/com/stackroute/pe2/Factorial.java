package com.stackroute.pe2;

public class Factorial {

/*public int fact(int num)
{
    //ADD YOUR CODE HERE
    return 0;
}*/
public long fac(long  x)
{ 
	long res;
    if(x==1)	
    	res=1;
    else
    	res=x*fac(x-1);
    return res;
}
}

