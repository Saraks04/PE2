package com.stackroute.pe2;

public class ReadFile 
{
	public String getcontent() 
	{
			return "";
	}
}
