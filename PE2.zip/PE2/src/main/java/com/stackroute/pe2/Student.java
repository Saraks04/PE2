package com.stackroute.pe2;

public class Student {
int great,less,sum,avg;
public int max(int num,int ar[])
{	great=ar[0];
    for(int i=1;i<num;i++)
    {
    	if(ar[i]>great)
    		great=ar[i];
    }
    return great;
}
public int avg(int num,int ar[])
{
	sum=0;
	for(int i=0;i<num;i++)
	{
		sum+=ar[i];
	}
	avg=sum/num;
    return avg;
}
public int min(int num,int ar[])
{
	 less=ar[0];
	 for(int i=1;i<num;i++)
	    {
	    	if(ar[i]<less)
	    		less=ar[i];
	    }
	    return less;
}

}